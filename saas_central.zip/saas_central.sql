-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 18, 2025 at 10:49 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saas_central`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(31, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(32, '2025_04_15_213723_create_jobs_table', 2),
(33, '2025_04_18_082416_create_users_table', 2),
(5, '2025_04_15_210709_create_companies_table', 1),
(6, '2025_04_15_211000_create_expenses_table', 1),
(7, '2025_04_15_211207_create_audit_logs_table', 1),
(30, '2019_08_19_000000_create_failed_jobs_table', 2),
(9, '2025_04_16_194103_create_tenants_table', 1),
(34, '2025_04_18_082748_create_tenants_table', 2),
(29, '2014_10_12_100000_create_password_reset_tokens_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Central\\User', 1, 'api', '3acc9474cfd61c7412602fefdeb62b702817d179f47ce3530ecd928ed6accd2c', '{\"tenant_id\":1}', NULL, NULL, '2025-04-18 13:31:31', '2025-04-18 13:31:31'),
(2, 'App\\Models\\Central\\User', 1, 'api', 'db16665eca889686c48f5b8d468cd76cb1c7c1da0c26db9f8ca0be425fc8c008', '{\"tenant_id\":1}', '2025-04-18 18:59:23', NULL, '2025-04-18 13:35:30', '2025-04-18 18:59:23'),
(3, 'App\\Models\\Central\\User', 1, 'api', '46c7715042707af68ce7a11514699dbbecf2f2846325ce86b7651e78b7cd84a2', '{\"tenant_id\":1}', NULL, NULL, '2025-04-18 13:41:42', '2025-04-18 13:41:42'),
(4, 'App\\Models\\Central\\User', 1, 'api', 'dd85cd1f43a433245a579170d50f99bbe6c714bb978d4b1f26e482472e638c17', '{\"tenant_id\":1}', NULL, NULL, '2025-04-18 18:55:21', '2025-04-18 18:55:21'),
(5, 'App\\Models\\Central\\User', 1, 'api', 'e3ab62d65e6dc2c6a51ee24965f4e425a3069b1a566bfcd291990543776c4935', '{\"tenant_id\":1}', NULL, NULL, '2025-04-18 18:58:23', '2025-04-18 18:58:23'),
(6, 'App\\Models\\Central\\User', 1, 'api', '358db95014f5391555aca4df57382fcafee6a688a6dd07278ad75123027891e2', '{\"tenant_id\":1}', NULL, NULL, '2025-04-18 18:59:24', '2025-04-18 18:59:24'),
(7, 'App\\Models\\Central\\User', 2, 'api', '0987bdf5e5b9035be9c7c0f56a84a879c94566ee9969f1dc025d9612cd6c7739', '{\"tenant_id\":2}', '2025-04-18 19:34:20', NULL, '2025-04-18 19:28:44', '2025-04-18 19:34:20'),
(8, 'App\\Models\\Central\\User', 2, 'api', 'fb8272a5486b09d531184ccd5092415ad9f13dc52672cc6514a02c7c73f9cc85', '{\"tenant_id\":2}', NULL, NULL, '2025-04-18 19:34:21', '2025-04-18 19:34:21');

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
CREATE TABLE IF NOT EXISTS `tenants` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `database_name` varchar(191) NOT NULL,
  `subdomain` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_email_unique` (`email`),
  UNIQUE KEY `tenants_database_name_unique` (`database_name`),
  UNIQUE KEY `tenants_subdomain_unique` (`subdomain`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`id`, `name`, `email`, `database_name`, `subdomain`, `created_at`, `updated_at`) VALUES
(1, 'jimsul', 'j.adinoyi.jnr@gmail.com', 'tenant_6802aedd2b051', 'jimsul', '2025-04-18 18:58:21', '2025-04-18 18:58:21'),
(2, 'jimsul222', 'jimsul@gmail.com', 'tenant_6802b5fa33027', 'jimsul222', '2025-04-18 19:28:42', '2025-04-18 19:28:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `tenant_ids` json DEFAULT NULL,
  `role` enum('SuperAdmin') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `tenant_ids`, `role`, `created_at`, `updated_at`) VALUES
(1, 'j.adinoyi.jnr@gmail.com', '$2y$12$yn4zjIr4FjSO3.TMc9zUIulH7kBhSG1eHlG0BNIfDy5u7e.Ji70uK', '[1]', NULL, '2025-04-18 18:58:23', '2025-04-18 18:58:23'),
(2, 'jimsul@gmail.com', '$2y$12$GJTAXWCGZ/4jIIhCx8ZHg.jclwOBUDfChatjLmM/AK3RGpgrnXbXm', '[2]', NULL, '2025-04-18 19:28:44', '2025-04-18 19:28:44');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
